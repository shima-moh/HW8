#include<stdio.h>
struct time
{
    int min;
    int sec;
};
struct runner
{
    char firstName[50];
    char lastName[50];
    char ID[50];
    struct time *record;
    struct time runningTime;
};
int main()
{
    int n;
    printf("enter number of attendees\n");
    scanf("%d",&n);
    struct runner a[n];
    printf("enter firstname: lastname: ID: record min: record sec: runningTime min: runningTime sec: \n");
    for(int i=0;i<n;i++)
        scanf("%s %s %s %d %d %d %d",&a[i].firstName,&a[i].lastName,&a[i].ID,(*a).record->min,(*a).record->sec,&a[i].runningTime.min,&a[i].runningTime.sec);
    int d=a[0].runningTime.min;
    int q=a[0].runningTime.sec;
    int c=0;
    for(int j=0;j<n;j++)
        if((a[j].runningTime.min<d)&&(a[j].runningTime.sec<q))
        {
            d=a[j].runningTime.min;
            q=a[j].runningTime.sec;
            c=j;
        }
       
    printf("name=%s last name=%s \n",&a[c].firstName,&a[c].lastName);
    
    
    if((a[c].record->min>a[c].runningTime.min)&&(a[c].record->sec>a[c].runningTime.sec))
        printf("the winner broke the record!\n");
    else
        printf("the winner didn't break the record!\n");


    int b=a[0].record->min;
    int u=a[0].record->sec;
    int g=0;
    for(int m=0;m<n;m++)
        if((a[m].record->min<=b)&&(a[m].record->sec<=u))
            {
                b=a[m].record->min;
                u=a[m].record->sec;
                g=m;
            }
    if(g==c)
        printf("the winner broke the best record!\n");
    else
        printf("the winner didn't break the best record!\n");
    int v=a[0].runningTime.min;
    int y=a[0].runningTime.sec;
    int e[n];
    int h=0;
    int k=0;
    while(k<n)
    {
        
        for(int l=0;l<n;l++)
        {
            if((a[l].runningTime.min<=v)&&(a[l].runningTime.sec<=y))
                h=l;
        }
        e[k]=a[h].runningTime.min;
        e[++k]=a[h].runningTime.sec;
        a[h].runningTime.min=10000;
        a[h].runningTime.sec=10000;
        k+=2;
    }
    printf("first name \t last name \t ID \t recprd \t running time \n");
    for(int o=0;o<n;o++)
        printf("%s \t %s \t %s \t %d \t %d\n",a[e[o]].firstName,a[e[o]].lastName,a[e[o]].ID,a[e[o]].record->min,a[e[o]].record->sec,
        a[e[o]].runningTime.min,a[e[o]].runningTime.sec);
} 